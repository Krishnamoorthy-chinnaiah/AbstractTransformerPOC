package com.io.json;

import java.io.IOException;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractTransformer;

import com.io.util.ProjectUtilities;
import com.json.jaxb.AddressType;
import com.json.jaxb.ParticipantType;
import com.json.jaxb.PersonalDemoType;
import com.json.jaxb.PersonalEmploymentInfoType;
import com.json.jaxb.PersonalInfoType;
import com.json.jaxb.PhoneType;
import com.json.jaxb.RetrieveEmployeeDetailsResp;
import com.json.jaxb.RetrieveEmployeeDetailsResponse;
import com.json.vo.employee.Address;
import com.json.vo.employee.Employee;
import com.json.vo.employee.Employees;
import com.json.vo.employee.Phone;
import com.json.vo.employeehistory.EmploymentInfoHistory;
import com.json.vo.employeehistory.Payroll;

public class CustomObjTransformer extends AbstractTransformer {

	private static final String EMPLOYEES = "employees_key";
	private static final String EMPLOYMENT_HISTORY = "employment_history_key";

	@Override
	protected Object doTransform(Object src, String enc) throws TransformerException {

		System.out.println(src);
		CopyOnWriteArrayList<String> list = (CopyOnWriteArrayList<String>) src;

		Employees employees = null;
		EmploymentInfoHistory employmentHistory = null;
		RetrieveEmployeeDetailsResponse response = new RetrieveEmployeeDetailsResponse();

	
		String empHistoryJson = list.get(0);
		String empJson = list.get(1);
		Iterator<String> s = list.iterator();
		
		employees = ((Employees) extractJsonObj(empJson, EMPLOYEES));
		employmentHistory = ((EmploymentInfoHistory) extractJsonObj(empHistoryJson, EMPLOYMENT_HISTORY));

		response = populateFinalResponse(employees, employmentHistory);
		return response;
	}

	

	private RetrieveEmployeeDetailsResponse populateFinalResponse(Employees employees,
			EmploymentInfoHistory employmentHistory) {
		RetrieveEmployeeDetailsResponse response = new RetrieveEmployeeDetailsResponse();
		RetrieveEmployeeDetailsResp resp = new RetrieveEmployeeDetailsResp();

		ParticipantType participantType = new ParticipantType();

		String requestEmployeeId = "997188007";

		for (Employee employee : employees.getEmployeeList()) {

			if (employee.getEmployeeId().equals(requestEmployeeId)) {

				PersonalInfoType personalInfoType = new PersonalInfoType();
				personalInfoType.setSSN(employee.getSsn());
				personalInfoType.setFirstName(employee.getFirstName());
				
				personalInfoType.setMiddleName(employee.getMiddleName());
				personalInfoType.setLastName(employee.getLastName());
				personalInfoType.setDateOfBirth(ProjectUtilities.DateToXMLGregorian(employee.getDateOfBirth()));				
				participantType.setPersonalInfo(personalInfoType);

				PersonalDemoType personalDemo = new PersonalDemoType();

				for (Phone phone : employee.getPhoneList()) {

					if (("HomeNumber").equalsIgnoreCase(phone.getType())) {
						PhoneType phoneType = new PhoneType();
						phoneType.setPhoneNumber(phone.getPhoneNumber());
						phoneType.setExtension(phone.getExtension());
						personalDemo.setHomePhone(phoneType);
					} else if(("WorkNumber").equalsIgnoreCase(phone.getType())) {
						PhoneType phoneType = new PhoneType();
						phoneType.setPhoneNumber(phone.getPhoneNumber());
						phoneType.setExtension(phone.getExtension());
						personalDemo.setWorkPhone(phoneType);
					}
				}

				for (Address jsonAddress : employee.getAddressList()) {
					AddressType address = new AddressType();
					address.setAddressLine1(jsonAddress.getAddress1());
					address.setCountry(jsonAddress.getCountryCode());
					personalDemo.setResidenceAddress(address);
				}
				
				participantType.setPersonalDemo(personalDemo);
				PersonalEmploymentInfoType personalEmploymentInfo = new PersonalEmploymentInfoType();
				personalEmploymentInfo.setEmployeeId(employee.getEmployeeId());

				for (Payroll jsonPayroll : employmentHistory.getEmpHistory().getPayrollHistory()) {
					if (employmentHistory.getEmployeeId().equals(requestEmployeeId)) {
						personalEmploymentInfo.setPayrollFrequency(new Integer(jsonPayroll.getPayrollFrequency()));
						break;
					}

				}
				participantType.setPersonalEmploymentInfo(personalEmploymentInfo);
				break;
				
			}

			
		}

		resp.setParticipant(participantType);
		response.setRetrieveEmployeeDetailsResp(resp);
		return response;
	}

	private Object extractJsonObj(String string, String key) {

		Object obj = null;
		if (EMPLOYEES.equals(key)) {
			obj = parseJson(string, Employees.class);
		} else if (EMPLOYMENT_HISTORY.equals(key)) {
			obj = parseJson(string, EmploymentInfoHistory.class);
		}
		return obj;
	}

	private Object parseJson(String string, Class class1) {

		Class paramClass = null;
		if (class1 == Employees.class) {
			paramClass = Employees.class;
		} else if (class1 == EmploymentInfoHistory.class) {
			paramClass = EmploymentInfoHistory.class;
		}

		Object object_ = null;
		ObjectMapper mapper = new ObjectMapper();
		try {

			object_ = mapper.readValue(string, paramClass);
			System.out.println(object_);
		} catch (JsonParseException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return object_;
	}
}
