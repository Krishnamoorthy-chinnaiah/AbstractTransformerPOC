package com.io.toobject;

import java.io.Serializable;
import java.util.ArrayList;

import org.codehaus.jackson.annotate.JsonProperty;

public class EmploymentHistory implements Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@JsonProperty(value = "payrollEmploymentHistories")
	private ArrayList<PayrollEmploymentHistories> payrollEmploymentHistories;
	
	
	public ArrayList<PayrollEmploymentHistories> getPayrollEmploymentHistories() {
		return payrollEmploymentHistories;
	}
	public void setPayrollEmploymentHistories(ArrayList<PayrollEmploymentHistories> payrollEmploymentHistories) {
		this.payrollEmploymentHistories = payrollEmploymentHistories;
	}
	
	
}
