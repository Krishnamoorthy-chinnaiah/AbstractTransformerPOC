package com.io.toobject;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonProperty;

public class EmploymentStatusAndDate implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@JsonProperty(value = "employmentStatus")
	private String employmentStatus;

	public String getEmploymentStatus() {
		return employmentStatus;
	}

	public void setEmploymentStatus(String employmentStatus) {
		this.employmentStatus = employmentStatus;
	}
	
	
}
