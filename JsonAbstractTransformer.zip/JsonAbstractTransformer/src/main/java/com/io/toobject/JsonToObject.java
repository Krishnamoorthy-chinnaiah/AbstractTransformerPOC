package com.io.toobject;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.annotate.JsonProperty;


@XmlRootElement
public class JsonToObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@JsonProperty(value = "employeeId")
	private String employeeId;
	
	

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	
	@JsonProperty(value = "employmentHistory")
	private EmploymentHistory employmentHistory;

	public EmploymentHistory getEmploymentHistory() {
		return employmentHistory;
	}

	public void setEmploymentHistory(EmploymentHistory employmentHistory) {
		this.employmentHistory = employmentHistory;
	}
	
	@Override
	public String toString() {

		StringBuilder  builder = new StringBuilder();
		builder.append("employeeId + " + employeeId);
		builder.append("payrollHistory[[");
		
		for (PayrollEmploymentHistories payrollHistory : this.getEmploymentHistory().getPayrollEmploymentHistories()) {
			builder.append("{{");
			builder.append("ClientId:" + payrollHistory.getClientId());
			builder.append("{{");
			builder.append("EmploymentStatus:" + payrollHistory.getEmploymentStatusAndDate().getEmploymentStatus());
			builder.append("}}");
			builder.append("}}");
		}
		builder.append("]]");

		return builder.toString();
	}

}
