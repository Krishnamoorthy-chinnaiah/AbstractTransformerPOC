package com.io.toobject;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonProperty;

public class PayrollEmploymentHistories implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@JsonProperty(value = "clientId")
	private String clientId;
	@JsonProperty(value = "employmentStatusAndDate")
	private EmploymentStatusAndDate employmentStatusAndDate;
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public EmploymentStatusAndDate getEmploymentStatusAndDate() {
		return employmentStatusAndDate;
	}
	public void setEmploymentStatusAndDate(EmploymentStatusAndDate employmentStatusAndDate) {
		this.employmentStatusAndDate = employmentStatusAndDate;
	}
	
	
	@JsonProperty(value = "dateOfHire")
	private String dateOfHire;
	public String getDateOfHire() {
		return dateOfHire;
	}
	public void setDateOfHire(String dateOfHire) {
		this.dateOfHire = dateOfHire;
	}
	
	
	
}
