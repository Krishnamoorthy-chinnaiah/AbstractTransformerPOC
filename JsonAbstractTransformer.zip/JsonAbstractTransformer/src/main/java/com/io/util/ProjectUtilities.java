package com.io.util;

import java.util.Date;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.json.JSONObject;

public class ProjectUtilities {

	
	public static XMLGregorianCalendar DateToXMLGregorian(Date date) {
		
		XMLGregorianCalendar xmlDate = null;
		GregorianCalendar gc = new GregorianCalendar();

		gc.setTime(date);

		try{
		    xmlDate = DatatypeFactory.newInstance().newXMLGregorianCalendar(gc);
		}
		catch(Exception e){
		    e.printStackTrace();
		}

		System.out.println("XMLGregorianCalendar :- " + xmlDate);
		return xmlDate;
	}
	
	public boolean isJSONResponseValid(String empHistoryJson) {

		
		JSONObject jsonObject = new JSONObject(empHistoryJson);
		System.out.println(jsonObject);
//		jsonObject.getBoolean("employees");
		String[] ss = JSONObject.getNames(jsonObject);

		for (String string : ss) {
			System.out.println(string);
		}
		System.out.println(ss);
		return false;
	}
	
}
