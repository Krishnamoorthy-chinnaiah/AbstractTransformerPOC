package com.json.vo.employee;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Address {
	@JsonProperty(value = "postalCode")
	private String postalCode;
	@JsonProperty(value = "state")
	private String state;
	@JsonProperty(value = "type")
	private String type;
	@JsonProperty(value = "address3")
	private String address3;
	@JsonProperty(value = "address2")
	private String address2;
	@JsonProperty(value = "address1")
	private String address1;
	@JsonProperty(value = "city")
	private String city;
	@JsonProperty(value = "countryCode")
	private String countryCode;
	
	public String getPostalCode() {
		return postalCode;
	}
	public String getState() {
		return state;
	}
	public String getType() {
		return type;
	}
	public String getAddress3() {
		return address3;
	}
	public String getAddress2() {
		return address2;
	}
	public String getAddress1() {
		return address1;
	}
	public String getCity() {
		return city;
	}
	public String getCountryCode() {
		return countryCode;
	}
	
	
	
}
