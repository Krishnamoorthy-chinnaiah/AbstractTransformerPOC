package com.json.vo.employee;

import java.util.List;

import org.codehaus.jackson.annotate.JsonProperty;

public class Addresses {
	@JsonProperty(value = "addresses")
	private List<Address> addressList = null;
}
