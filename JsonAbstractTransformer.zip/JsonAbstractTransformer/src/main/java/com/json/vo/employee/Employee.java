package com.json.vo.employee;

import java.util.Date;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

import com.fasterxml.jackson.annotation.JsonFormat;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Employee {

	@JsonProperty(value = "addresses")
	private List<Address> addressList = null;
	
	@JsonProperty(value = "firstName")
	private String firstName = null;
	private String suffix = null;
	
	@JsonProperty(value = "employeeKey")
	private String employeeKey = null;
	private String maritalStatus = null;
	
	private String communicationMethod = null;
	
	@JsonProperty(value = "locationId")
	private String locationId = null;
	@JsonProperty(value = "ssn")
	private String ssn = null;
	private String residencyCode = null;
	private String employeeId = null;
	private String lastName = null;
	
	
	@JsonProperty(value = "employerId")
	private String employerId = null;
	
	@JsonFormat(pattern="yyyy-MM-dd")
	@JsonProperty(value = "dateOfBirth" )
	private Date dateOfBirth = null;
	private String tiaaEmployeeId = null;
	private String middleName = null;
	private String clientId = null;
	private String genderId = null;
	private String title = null;
	
	@JsonProperty(value = "phones")
	private List<Phone> phoneList = null;

	public List<Address> getAddressList() {
		return addressList;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getSuffix() {
		return suffix;
	}

	public String getEmployeeKey() {
		return employeeKey;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public String getCommunicationMethod() {
		return communicationMethod;
	}

	public String getLocationId() {
		return locationId;
	}

	public String getSsn() {
		return ssn;
	}

	public String getResidencyCode() {
		return residencyCode;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public String getLastName() {
		return lastName;
	}

	public String getEmployerId() {
		return employerId;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public String getTiaaEmployeeId() {
		return tiaaEmployeeId;
	}

	public String getMiddleName() {
		return middleName;
	}

	public String getClientId() {
		return clientId;
	}

	public String getGenderId() {
		return genderId;
	}

	public String getTitle() {
		return title;
	}

	public List<Phone> getPhoneList() {
		return phoneList;
	}
	
	
	
	
	
}
