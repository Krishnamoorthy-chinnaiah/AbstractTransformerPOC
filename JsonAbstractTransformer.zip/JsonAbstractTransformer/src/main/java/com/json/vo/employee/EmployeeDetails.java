package com.json.vo.employee;

public class EmployeeDetails {

	private Employees employees;
	
}
