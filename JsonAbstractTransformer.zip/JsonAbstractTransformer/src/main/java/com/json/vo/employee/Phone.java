package com.json.vo.employee;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Phone {
	@JsonProperty(value = "phoneNumber")
	private String phoneNumber = null;
	@JsonProperty(value = "extension")
	private String extension = null;
	@JsonProperty(value = "type")
	private String type = null;
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public String getExtension() {
		return extension;
	}
	public String getType() {
		return type;
	}
	
	
}
