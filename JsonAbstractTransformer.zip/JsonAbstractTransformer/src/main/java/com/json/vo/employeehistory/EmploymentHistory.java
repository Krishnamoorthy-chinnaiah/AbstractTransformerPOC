package com.json.vo.employeehistory;

import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class EmploymentHistory {

	@JsonProperty(value = "payrollEmploymentHistories")
	private List<Payroll> payrollHistory = null;

	public List<Payroll> getPayrollHistory() {
		return payrollHistory;
	}

}
