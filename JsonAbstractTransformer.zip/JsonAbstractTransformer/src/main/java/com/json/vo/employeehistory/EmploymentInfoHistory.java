package com.json.vo.employeehistory;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class EmploymentInfoHistory {

	@JsonProperty(value = "employeeId")
	private String employeeId = null;
	@JsonProperty(value = "asOfDate")
	private String asOfDate = null;

	@JsonProperty(value = "employmentHistory")
	private EmploymentHistory empHistory = null;

	public String getEmployeeId() {
		return employeeId;
	}

	public String getAsOfDate() {
		return asOfDate;
	}

	public EmploymentHistory getEmpHistory() {
		return empHistory;
	}

	
}
