package com.json.vo.employeehistory;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class EmploymentStatusAndDate {

	@JsonProperty(value = "employmentStatus")
	private String employmentStatus = null;

	@JsonProperty(value = "employmentSubStatus")
	private String employmentSubStatus = null;
	@JsonProperty(value = "employmentStatusDate")
	private String employmentStatusDate = null;

}
