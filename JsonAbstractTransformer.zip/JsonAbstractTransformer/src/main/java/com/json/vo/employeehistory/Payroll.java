package com.json.vo.employeehistory;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Payroll {

	@JsonProperty(value = "empStatusAndDate")
	private EmploymentStatusAndDate empStatusAndDate = null;

	@JsonProperty(value = "clientId")
	private String clientId = null;

	@JsonProperty(value = "employerId")
	private String employerId = null;

	@JsonProperty(value = "employerName")
	private String employerName = null;

	@JsonProperty(value = "locationId")
	private String locationId = null;
	@JsonProperty(value = "planId")
	private String planId = null;
	@JsonProperty(value = "hrSubArea")
	private String hrSubArea = null;
	@JsonProperty(value = "unionCode")
	private String unionCode = null;
	@JsonProperty(value = "hceCode")
	private String hceCode = null;
	@JsonProperty(value = "keyEmployeeCode")
	private String keyEmployeeCode = null;
	@JsonProperty(value = "employeeType")
	private String employeeType = null;
	@JsonProperty(value = "payrollFrequency")
	private String payrollFrequency = null;
	@JsonProperty(value = "payrollMode")
	private String payrollMode = null;

	@JsonProperty(value = "dateOfHire")
	private String dateOfHire = null;
	@JsonProperty(value = "adjustedDateOfHire")
	private String adjustedDateOfHire = null;
	@JsonProperty(value = "isCurrentFile")
	private String isCurrentFile = null;
	@JsonProperty(value = "employmentHistoryDate")
	private String employmentHistoryDate = null;
	@JsonProperty(value = "severanceDate")
	private String severanceDate = null;
	public EmploymentStatusAndDate getEmpStatusAndDate() {
		return empStatusAndDate;
	}
	public String getClientId() {
		return clientId;
	}
	public String getEmployerId() {
		return employerId;
	}
	public String getEmployerName() {
		return employerName;
	}
	public String getLocationId() {
		return locationId;
	}
	public String getPlanId() {
		return planId;
	}
	public String getHrSubArea() {
		return hrSubArea;
	}
	public String getUnionCode() {
		return unionCode;
	}
	public String getHceCode() {
		return hceCode;
	}
	public String getKeyEmployeeCode() {
		return keyEmployeeCode;
	}
	public String getEmployeeType() {
		return employeeType;
	}
	public String getPayrollFrequency() {
		return payrollFrequency;
	}
	public String getPayrollMode() {
		return payrollMode;
	}
	public String getDateOfHire() {
		return dateOfHire;
	}
	public String getAdjustedDateOfHire() {
		return adjustedDateOfHire;
	}
	public String getIsCurrentFile() {
		return isCurrentFile;
	}
	public String getEmploymentHistoryDate() {
		return employmentHistoryDate;
	}
	public String getSeveranceDate() {
		return severanceDate;
	}

	
	
}
